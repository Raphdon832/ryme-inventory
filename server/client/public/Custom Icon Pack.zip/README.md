
  # Custom Icon Pack

  This is a code bundle for Custom Icon Pack. The original project is available at https://www.figma.com/design/pzDHXFKn8IZ0McVQIMKY1R/Custom-Icon-Pack.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  