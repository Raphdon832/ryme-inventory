import { useState } from 'react';
import {
  DashboardIcon,
  InventoryIcon,
  ProductsIcon,
  AddIcon,
  EditIcon,
  DeleteIcon,
  SearchIcon,
  UsersIcon,
  SettingsIcon,
  ReportsIcon,
  CategoriesIcon,
  WarehouseIcon,
  ShippingIcon,
  NotificationsIcon,
  AnalyticsIcon,
  BarcodeIcon,
  CartIcon,
  FilterIcon,
  DownloadIcon,
  UploadIcon,
  BoxIcon,
  TagsIcon,
  ClockIcon,
  StarIcon,
  MenuIcon,
  CloseIcon,
  CheckIcon,
  AlertIcon,
  CalendarIcon,
  ExportIcon,
  ImportIcon,
  RefreshIcon,
  EyeIcon,
  LockIcon,
  UnlockIcon,
  ArrowRightIcon,
  ArrowLeftIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  DollarIcon,
  PercentageIcon,
  LinkIcon,
  PrintIcon,
  PackageIcon,
} from '@/app/components/icons/CustomIcons';

export default function App() {
  const [iconSize, setIconSize] = useState(32);
  const [iconColor, setIconColor] = useState('#3b82f6');
  const [copiedIcon, setCopiedIcon] = useState<string | null>(null);

  const icons = [
    { name: 'DashboardIcon', component: DashboardIcon, category: 'Navigation' },
    { name: 'InventoryIcon', component: InventoryIcon, category: 'Main Features' },
    { name: 'ProductsIcon', component: ProductsIcon, category: 'Main Features' },
    { name: 'WarehouseIcon', component: WarehouseIcon, category: 'Main Features' },
    { name: 'ShippingIcon', component: ShippingIcon, category: 'Main Features' },
    { name: 'BoxIcon', component: BoxIcon, category: 'Main Features' },
    { name: 'PackageIcon', component: PackageIcon, category: 'Main Features' },
    { name: 'CategoriesIcon', component: CategoriesIcon, category: 'Organization' },
    { name: 'TagsIcon', component: TagsIcon, category: 'Organization' },
    { name: 'BarcodeIcon', component: BarcodeIcon, category: 'Main Features' },
    { name: 'CartIcon', component: CartIcon, category: 'Commerce' },
    { name: 'AddIcon', component: AddIcon, category: 'Actions' },
    { name: 'EditIcon', component: EditIcon, category: 'Actions' },
    { name: 'DeleteIcon', component: DeleteIcon, category: 'Actions' },
    { name: 'SearchIcon', component: SearchIcon, category: 'Actions' },
    { name: 'FilterIcon', component: FilterIcon, category: 'Actions' },
    { name: 'RefreshIcon', component: RefreshIcon, category: 'Actions' },
    { name: 'UsersIcon', component: UsersIcon, category: 'User Management' },
    { name: 'SettingsIcon', component: SettingsIcon, category: 'System' },
    { name: 'ReportsIcon', component: ReportsIcon, category: 'Analytics' },
    { name: 'AnalyticsIcon', component: AnalyticsIcon, category: 'Analytics' },
    { name: 'NotificationsIcon', component: NotificationsIcon, category: 'System' },
    { name: 'DownloadIcon', component: DownloadIcon, category: 'File Operations' },
    { name: 'UploadIcon', component: UploadIcon, category: 'File Operations' },
    { name: 'ExportIcon', component: ExportIcon, category: 'File Operations' },
    { name: 'ImportIcon', component: ImportIcon, category: 'File Operations' },
    { name: 'PrintIcon', component: PrintIcon, category: 'File Operations' },
    { name: 'ClockIcon', component: ClockIcon, category: 'System' },
    { name: 'CalendarIcon', component: CalendarIcon, category: 'System' },
    { name: 'StarIcon', component: StarIcon, category: 'UI Elements' },
    { name: 'MenuIcon', component: MenuIcon, category: 'Navigation' },
    { name: 'CloseIcon', component: CloseIcon, category: 'UI Elements' },
    { name: 'CheckIcon', component: CheckIcon, category: 'UI Elements' },
    { name: 'AlertIcon', component: AlertIcon, category: 'System' },
    { name: 'EyeIcon', component: EyeIcon, category: 'Actions' },
    { name: 'LockIcon', component: LockIcon, category: 'Security' },
    { name: 'UnlockIcon', component: UnlockIcon, category: 'Security' },
    { name: 'ArrowRightIcon', component: ArrowRightIcon, category: 'Navigation' },
    { name: 'ArrowLeftIcon', component: ArrowLeftIcon, category: 'Navigation' },
    { name: 'ChevronDownIcon', component: ChevronDownIcon, category: 'Navigation' },
    { name: 'ChevronUpIcon', component: ChevronUpIcon, category: 'Navigation' },
    { name: 'DollarIcon', component: DollarIcon, category: 'Commerce' },
    { name: 'PercentageIcon', component: PercentageIcon, category: 'Commerce' },
    { name: 'LinkIcon', component: LinkIcon, category: 'UI Elements' },
  ];

  const categories = Array.from(new Set(icons.map(icon => icon.category)));

  const copyToClipboard = (iconName: string) => {
    const importStatement = `import { ${iconName} } from '@/app/components/icons/CustomIcons';\n\n<${iconName} size={24} color="#000000" />`;
    navigator.clipboard.writeText(importStatement);
    setCopiedIcon(iconName);
    setTimeout(() => setCopiedIcon(null), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Ryme Inventory Icon Pack</h1>
              <p className="mt-2 text-slate-600">Complete custom icon set for inventory management</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-slate-500">Total Icons</div>
                <div className="text-2xl font-bold text-blue-600">{icons.length}</div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="mt-6 flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-slate-700">Size:</label>
              <input
                type="range"
                min="16"
                max="64"
                value={iconSize}
                onChange={(e) => setIconSize(Number(e.target.value))}
                className="w-32"
              />
              <span className="text-sm text-slate-600 w-12">{iconSize}px</span>
            </div>
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-slate-700">Color:</label>
              <input
                type="color"
                value={iconColor}
                onChange={(e) => setIconColor(e.target.value)}
                className="h-10 w-20 rounded border border-slate-300 cursor-pointer"
              />
              <span className="text-sm text-slate-600 font-mono">{iconColor}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {categories.map((category) => (
          <section key={category} className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <h2 className="text-2xl font-semibold text-slate-800">{category}</h2>
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                {icons.filter(icon => icon.category === category).length} icons
              </span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {icons
                .filter(icon => icon.category === category)
                .map(({ name, component: Icon }) => (
                  <div
                    key={name}
                    onClick={() => copyToClipboard(name)}
                    className="group relative bg-white rounded-xl border-2 border-slate-200 hover:border-blue-400 transition-all duration-200 cursor-pointer overflow-hidden hover:shadow-lg"
                  >
                    <div className="aspect-square flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 to-white group-hover:from-blue-50 group-hover:to-blue-100/50 transition-colors">
                      <Icon size={iconSize} color={iconColor} />
                    </div>
                    <div className="p-3 border-t border-slate-100 bg-white">
                      <p className="text-xs font-medium text-slate-700 truncate group-hover:text-blue-600 transition-colors">
                        {name}
                      </p>
                    </div>
                    
                    {/* Copied notification */}
                    {copiedIcon === name && (
                      <div className="absolute inset-0 bg-green-500/90 flex items-center justify-center">
                        <div className="text-white text-center">
                          <CheckIcon size={32} color="white" />
                          <p className="text-sm font-medium mt-2">Copied!</p>
                        </div>
                      </div>
                    )}

                    {/* Hover overlay */}
                    <div className="absolute inset-0 bg-blue-600/0 group-hover:bg-blue-600/5 transition-colors pointer-events-none" />
                  </div>
                ))}
            </div>
          </section>
        ))}

        {/* Usage Guide */}
        <section className="mt-16 bg-white rounded-2xl border-2 border-slate-200 p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">Usage Guide</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-slate-700 mb-3">Import Icons</h3>
              <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
                <code className="text-sm text-green-400">
                  import {'{ DashboardIcon, ProductsIcon }'} from '@/app/components/icons/CustomIcons';
                </code>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-700 mb-3">Use in Components</h3>
              <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
                <code className="text-sm text-green-400">
                  {'<DashboardIcon size={24} color="#000000" className="my-icon" />'}
                </code>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-700 mb-3">Available Props</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <p className="font-mono text-sm text-blue-600 mb-1">size</p>
                  <p className="text-xs text-slate-600">Icon size in pixels (default: 24)</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <p className="font-mono text-sm text-blue-600 mb-1">color</p>
                  <p className="text-xs text-slate-600">Icon color (default: currentColor)</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <p className="font-mono text-sm text-blue-600 mb-1">className</p>
                  <p className="text-xs text-slate-600">Additional CSS classes</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                <strong>💡 Tip:</strong> Click any icon above to copy its import and usage code to your clipboard!
              </p>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <CheckIcon size={24} color="#3b82f6" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Fully Customizable</h3>
            <p className="text-sm text-slate-600">Adjust size, color, and styling with simple props</p>
          </div>
          
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <BoxIcon size={24} color="#22c55e" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Inventory Focused</h3>
            <p className="text-sm text-slate-600">Purpose-built for inventory management systems</p>
          </div>
          
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <StarIcon size={24} color="#a855f7" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Premium Quality</h3>
            <p className="text-sm text-slate-600">Clean, scalable SVG icons with consistent design</p>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-sm text-slate-600">
            <p>Custom Icon Pack for <span className="font-semibold text-slate-900">Ryme Inventory</span></p>
            <p className="mt-1">© 2026 - All rights reserved</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
